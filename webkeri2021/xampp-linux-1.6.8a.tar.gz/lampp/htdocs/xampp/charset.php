<?
        header("Content-Type: text/html; charset=gb2312");
?>
