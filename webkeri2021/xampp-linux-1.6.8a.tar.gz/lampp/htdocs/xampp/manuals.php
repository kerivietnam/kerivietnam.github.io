<? include("langsettings.php"); ?>
<html>
<head>
<meta name="author" content="Kai Oswald Seidler">
<link href="xampp.css" rel="stylesheet" type="text/css">
</head>

<body>
&nbsp;<p>
<h1><?=$TEXT['manuals-head']?></h1>

<?=$TEXT['manuals-text1']?>
<?=$TEXT['manuals-list1']?>
<?=$TEXT['manuals-text2']?>
<?=$TEXT['manuals-list2']?>
<?=$TEXT['manuals-text3']?>


</body>
</html>
